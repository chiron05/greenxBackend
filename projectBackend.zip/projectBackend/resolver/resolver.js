
const UserSchema=require('../Models/User.model');
const CategorySchema=require('../Models/Category.model');
const ProductSchema=require('../Models/Product.model');
const SubCategorySchema=require('../Models/Subcategory.model');


const resolver={
    getAllCategory:async()=>{
        const result =await CategorySchema.find({}).populate('subCategoryList')
        if(result){
            return result
        }
        else{
            console.log('Error in geting category')
        }
    },
    getAllProducts:async()=>{
        const result=await ProductSchema.find({});
        if(result){
            return result;
        }
        else{
            console.log('Error in getting products')
        }
    },
    getAllSubcategory:async()=>{
        const result=await SubCategorySchema.find({});
        if(result){
            return result;
        }
        else{
            console.log('Error in getting products')
        }
    },
    getSubcategoryByCategoryId:async(args)=>{
        const result=await SubCategorySchema.find({categoryID:args.categoryID});
        if(result){
            return result;
        }
        else{
            console.log('No Subcategory found')
        }
    },
    getProductByCategoryID:async(args)=>{
        return CategorySchema.find({_id:args.categoryID}).then((result)=>{
            return SubCategorySchema.find({categoryID:result}).then((res)=>{
                console.log(res)
               return res;
            }).catch(err=>{
                console.log(err)
            })
        }).catch(err=>{
            console.log(err)
        })
         
        
    }
}

module.exports=resolver;