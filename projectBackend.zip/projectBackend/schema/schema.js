const {buildSchema} = require('graphql');

const Schema=buildSchema(`

    type product{
        subcategoryID:String
        sellerID:String
        name:String
        price:Int
        description:String
        quantity:String
        images:String
        location:String
    }

    type subcategory{
        _id:String
        name:String
        categoryID:String
        productList:[product]
    }

    type category{
        name:String
        subCategoryList:[subcategory]
    }

    type Query{
       getAllCategory:[category]
       getAllProducts:[product]
       getAllSubcategory:[subcategory]
       getSubcategoryByCategoryId(categoryID:String):[subcategory]
       getProductByCategoryID(categoryID:String):[subcategory]
       
       
    }

    
   
`);

module.exports=Schema;